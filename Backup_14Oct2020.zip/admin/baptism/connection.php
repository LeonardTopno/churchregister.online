
<?php
// Establish Connection with Database
$con=mysqli_connect("localhost","develope_root","Migids@123","develope_universe");
// Select Database
// mysql_select_db($con);
//Connect using PDO.
//$database ="develope_universe";
//$user="develope_root";
//$password="Migids@123";
//$server="localhost";
//$pdo = new PDO("mysql:host=$server;dbname=$database", $user, $password);
// Specify the query to execute
//$sql = "select * from userinfo";
// Execute query
//$result = mysqli_query($con,$sql);
?>