<?php

    include "connection.php";
   // $con=mysqli_connect("localhost","develope_root","Migids@123","develope_universe");
    
	$FName=$_POST['fname'];
	$MName=$_POST['mname'];
	$LName=$_POST['lname'];
	$Gender=$_POST['radio-stacked'];
	$DOB=$_POST['dob'];
	$Padd=$_POST['padd'];
	$Cadd=$_POST['cadd'];
	$Fathername=$_POST['fathername'];
	$Fathersname=$_POST['fathersname'];
	$Foccupation=$_POST['foccupation'];
	$Mothername=$_POST['mothername'];
	$Mothersname=$_POST['mothersname'];
	$Moccupation=$_POST['moccupation'];
	$Mobile=$_POST['mobile'];
	$Email=$_POST['email'];
	
	// this info inserts into eventbaptism
	$DOBaptism=$_POST['dobaptism'];
	$GFname=$_POST['GFname'];
	$GFdom=$_POST['GFdomicile'];
	$GMname=$_POST['GMname'];
	$GMdom=$_POST['GMdomicile'];
	$Country=$_POST['country'];	
	$State=$_POST['state'];
	$District=$_POST['district'];
	$Diocese=$_POST['diocese'];
	$Church=$_POST['church'];
	$Bby=$_POST['bby'];
	
	
	$uploaddir='uploads/'; // web root dir name for photo upload
	
	$uploadfile=$uploaddir.basename($_FILES['file']['name']);
	
//	if(move_uploaded_file($_FILES['file']['tmp_name'],$uploadfile))
//	{
//		echo "file is valid";
//	}
//	else
//	{
//	echo "not Valid";
//	} //photo upload ends here





   
    $sql1 = "INSERT INTO eventbaptism (bapt_church_id,bapt_date,godfather_name,godfather_domicile,godmother_name,godmother_domicile,country,states,district,diocese,church,clergyman) VALUES (NULL,'".$DOBaptism."', '".$GFname."','".$GFdom."','".$GMname."','".$GMdom."','".$Country."','".$State."','".$District."','".$Diocese."','".$Church."','".$Bby."')";
	$sql = "INSERT INTO userinfo (user_id,first_name,middle_name,last_name,gender_id,dob,permanent_address,current_address,father_name,father_surname,father_occupation,mother_name,mother_surname,mother_occupation,mobile,email) VALUES (NULL,'".$FName."','".$MName."','".$LName."','".$Gender."','".$DOB."','".$Padd."','".$Cadd."','".$Fathername."','".$Fathersname."','".$Foccupation."','".$Mothername."','".$Mothersname."','".$Moccupation."','".$Mobile."','".$Email."')";
	
    
    // execute query
    mysqli_query ($con,$sql1);
	mysqli_query ($con,$sql);
	
	
   
   // if($con->query($sql)===TRUE)
    if($sql && $sql1==TRUE)
    {
   	echo '<script type="text/javascript">alert("Baptism Details Registered Succesfully");window.location=\'form_baptism.php\';</script>'; 
    }
    else
    {
     echo '<script type="text/javascript">alert("Baptism Detail Not Registered");window.location=\'index.php\';</script>';   
    }


?>