<?php

    include "connection.php";
   // $con=mysqli_connect("localhost","develope_root","Migids@123","develope_universe");
    
	
	
	// this info inserts into eventbaptism
	$DOBaptism=$_POST['dobaptism'];
	$GFname=$_POST['GFname'];
	$GFdom=$_POST['GFdomicile'];
	$GMname=$_POST['GMname'];
	$GMdom=$_POST['GMdomicile'];
	$Country=$_POST['country'];	
	$State=$_POST['state'];
	$District=$_POST['district'];
	$Diocese=$_POST['diocese'];
	$Church=$_POST['church'];
	$Bby=$_POST['bby'];
	
	
    $sql1 = "INSERT INTO eventbaptism (bapt_church_id,godfather_name,godfather_domicile,godmother_name,godmother_domicile,country,states,district,diocese,church,clergyman) VALUES (NULL,'".$GFname."','".$GFdom."','".$GMname."','".$GMdom."','".$Country."','".$State."','".$District."','".$Diocese."','".$Church."','".$Bby."')";
	
    
    // execute query
    mysqli_query ($con,$sql1);
	
	
	
   
   // if($con->query($sql)===TRUE)
    if($sql1==TRUE)
    {
   	echo '<script type="text/javascript">alert("Baptism Details Registered Succesfully");window.location=\'form_baptism.php\';</script>'; 
    }
    else
    {
     echo '<script type="text/javascript">alert("Baptism Detail Not Registered");window.location=\'index.php\';</script>';   
    }


?>