<?php 
require('pdf/fpdf.php'); 

// Establish Connection with Database
$con=mysqli_connect("localhost","develope_root","Migids@123","develope_universe");

$id=$_GET['Id'];
// Removes the first 20 characters of timestamp including whitespaces
$reg_id=substr($id,20);

// Specify the query to execute
$sql = "select * from userinfo where user_id=". ($_GET["Id"]) ."";


$pdf = new FPDF('P', 'pt', 'A4');
// sizes are defines in millimetres

$pdf->AddPage(); 

//$pdf->SetXY(Left Margin,Top Margin);
//$pdf->Cell(Cell Width,Cell Height,'TEXT TO BE DISPLAYED');
//$pdf->Line(30,100,0,100);

// Diocese header column 
//$pdf->SetFont('Arial','',16);
$pdf->SetFont('Arial','',16);
$pdf->SetXY(170,50);
$pdf->Cell(80,10,'RANCHI CATHOLIC ARCHDIOCESE');

// Certificate header column
$pdf->SetXY(210,80);
$pdf->SetFont('Arial', 'B', 14);
$pdf->Cell(80,10,'CERTIFICATE OF BAPTISM');

// Parish Line
$pdf->SetXY(30,110);
$pdf->SetFont('Arial','',10);
$pdf->Cell(10,10,'Parish Address :............................................................................................................................................',0,0,L,false);
//$pdf->SetFont('Arial','',14);
//$pdf->Cell(40,10,$row->name,0,0,L,false); 

// Full Address from DB
$pdf->SetXY(30,135);
$pdf->Cell(30,10,'P.O.:...................................................',0,0,L,false);  
//$pdf->SetFont('Arial','',14);
//$pdf->Cell(40,10,$row->name,0,0,L,false); 

$pdf->SetXY(210,135);
$pdf->SetFont('Arial','',10);
$pdf->Cell(30,10,'Dist.:...................................................',0,0,L,false); 
//$pdf->SetFont('Arial','',14);
//$pdf->Cell(40,10,$row->class,0,0,L,false);

$pdf->SetXY(400,135);
$pdf->SetFont('Arial','',10);
$pdf->Cell(30,10,'PIN.:............................',0,0,L,false); 
//$pdf->SetFont('Arial','',14);
//$pdf->Cell(40,10,$row->class,0,0,L,false);

$pdf->SetXY(510,135);
$pdf->SetFont('Arial','',10);
$pdf->Cell(30,10,'Jharkhand',0,0,L,false); 
//$pdf->SetFont('Arial','',14);
//$pdf->Cell(40,10,$row->class,0,0,L,false);

//$pdf->Line(Laft Margin,Left Top Margin,LINE LENGTH,Right Top Margin );
// Line 1
$pdf->SetXY(30,150);
$pdf->Line(33,150,570,150);

$pdf->SetXY(30,160);
$pdf->SetFont('Arial','',10);
$pdf->Cell(30,10,'REGISTRATION NO.',0,0,L,false); 
$pdf->SetXY(190,160);
$pdf->SetFont('Arial','',10);
//$pdf->Cell(40,10,$id,0,0,L,false);
$pdf->Cell(40,10,'B' . htmlspecialchars($reg_id) . '',0,0,L,false);


// Line 2
$pdf->SetXY(30,150);
$pdf->Line(33,180,570,180);
// Line 3
$pdf->SetXY(30,150);
$pdf->Line(33,210,570,210);
// Line 4
$pdf->SetXY(30,150);
$pdf->Line(33,240,570,240);
// Line 5
$pdf->SetXY(30,150);
$pdf->Line(33,270,570,270);
// Line 6
$pdf->SetXY(30,150);
$pdf->Line(33,300,570,300);
// Line 7
$pdf->SetXY(30,150);
$pdf->Line(33,330,570,330);
// Line 8
$pdf->SetXY(30,150);
$pdf->Line(33,360,570,360);
// Line 9
$pdf->SetXY(30,150);
$pdf->Line(33,390,570,390);
// Line 10
$pdf->SetXY(30,150);
$pdf->Line(33,420,570,420);
// Line 11
$pdf->SetXY(30,150);
$pdf->Line(33,450,570,450);
// Line 12
$pdf->SetXY(30,150);
$pdf->Line(33,480,570,480);
// Line 13
$pdf->SetXY(30,150);
$pdf->Line(33,510,570,510);
// Verticle Line 
//$pdf->Line(Left Margin,Left Top Margin,LINE LENGTH,Right Top Margin );
//$pdf->SetXY(30,150);
$pdf->Line(180,510,180,150);



//$pdf->SetXY(30,130);
//$pdf->SetFont('Arial','UB',16);
//$pdf->Cell(100,10,'SUBJECT:',0,0,L,false);  
//$pdf->Cell(50,10,'MARK',0,1,L,false);  
//$pdf->SetFont('Arial','',14);
//$pdf->SetX(30);
//$pdf->Cell(100,10,'SOCIAL',0,0,L,false);  
//$pdf->Cell(50,10,$row->social,0,1,L,false); 

//$pdf->SetX(30);
//$pdf->Cell(100,10,'SCIENCE',0,0,L,false);  
//$pdf->Cell(50,10,$row->science,0,1,L,false); 

//$pdf->SetX(30);
//$pdf->Cell(100,10,'MATH',0,0,L,false); 
//$pdf->Cell(50,10,$row->math,0,1,L,false); 

//$pdf->Line(30,170,150,170);

//$pdf->SetX(30);
//$pdf->Cell(98,10,'TOTAL',0,0,L,false); 
//$pdf->Cell(50,10,$row->total,0,1,L,false);

//$pdf->SetXY(430,220);
$pdf->SetXY(430,700);
$pdf->Cell(50,10,'Signature & Seal',0,1,L,false);

$pdf->Output();

?>